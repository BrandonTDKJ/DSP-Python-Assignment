from iir_filter import  IIR_filter
from iir_filter import  IIR2_filter
import matplotlib.pyplot as plt
import numpy as np
from scipy.signal import butter
import numpy as np
import pandas as pd

def unitTest(datas):
    coeffciency = [[0.5,0.5,0.5,0.5,0.5,0.5]]
    IIR_filter1 = IIR_filter(coeffciency)
    output = []
    for data in datas:
        output.append(IIR_filter1.filter(data))
    return output

def unitTestForChain(datas):
    coeffciency = [[0.5, 0.5, 0.5, 0.5, 0.5, 0.5],[0.5, 0.5, 0.5, 0.5, 0.5, 0.5]]
    IIR_filter1 = IIR_filter(coeffciency)
    output = []
    for data in datas:
        output.append(IIR_filter1.filter(data))
    return output

def valueChecker(inArray, outArray):
    if inArray[0] == outArray[0]  and inArray[1] == outArray[1] and inArray[2] == outArray[2]:
        print("Unit Test has Passed")
    else:
        print("Unit Test has failed")


if __name__ == '__main__':

  #Input Array with known output for known coefficients
  inputArray = [5,-3,1]

  #Initialise a 2nd order filter
  coeffciency1 = [[0.5,0.5,0.5,0.5,0.5,0.5]]
  filter1 = IIR_filter(coeffciency1)

  # Initialise a chain of2nd order filters
  coeffciency2 = [[0.5, 0.5, 0.5, 0.5, 0.5, 0.5], [0.5, 0.5, 0.5, 0.5, 0.5, 0.5]]
  filter2 = IIR_filter(coeffciency2)

  # Desired output for 2nd order filters
  desiredOut2ndOrder = [2.5,-0.25, 0.375]

  # Desired output for a chain of 2 2nd order filters
  desiredOutChain = [1.25,0.5,0.4375]

  print("Perform unit test for 2nd order filter")
  #Perform Unit test for the Second order filter
  filter1.unitTest(inputArray,desiredOut2ndOrder)

  print("Perform unit test for chain of 2nd order filter")
  #Perform Unit Test for the chain of 2nd Order filters
  filter2.unitTest(inputArray, desiredOutChain)

