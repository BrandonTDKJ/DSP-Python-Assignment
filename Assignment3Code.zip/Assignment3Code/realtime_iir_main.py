#!/usr/bin/python3
"""
Plots channel zero at 1kHz. Requires pyqtgraph.

Copyright (c) 2018-2021, Bernd Porr <mail@berndporr.me.uk>
see LICENSE file.

"""

import sys
from datetime import datetime, timedelta
import pyqtgraph as pg
from pyqtgraph.Qt import QtCore, QtGui

from iir_filter import IIR2_filter
from iir_filter import IIR_filter

from scipy.signal import butter
import time

import numpy as np

from pyfirmata2 import Arduino

PORT = Arduino.AUTODETECT

# create a global QT application object
# noinspection PyUnresolvedReferences
app = QtGui.QApplication(sys.argv)

# signals to all threads in endless loops that we'd like to run these
running = True


class QtPanningPlot:

    def __init__(self, title, maxVal, minVal):
        self.win = pg.GraphicsLayoutWidget()

        self.win.setWindowTitle(title)
        self.plt = self.win.addPlot()
        self.maxVal = maxVal
        self.minVal = minVal
        self.plt.setYRange(self.minVal, self.maxVal)
        self.plt.setXRange(0, 600)
        self.curve = self.plt.plot()
        self.data = []
        # any additional initalisation code goes here (filters etc)
        self.timer = QtCore.QTimer()
        self.timer.timeout.connect(self.update)
        self.timer.start(100)
        self.layout = QtGui.QGridLayout()
        self.win.setLayout(self.layout)
        #self.text =pg.LabelItem("Sample Rate")
        #self.label = self.win.addItem(self.text)
        self.win.show()

    def update(self):
        self.data = self.data[-500:]
        if self.data:
            self.curve.setData(np.hstack(self.data))

    def addData(self, d):
        self.data.append(d)




# Let's create two instances of plot windows
#create 5 plot to record
qtPanningPlot1 = QtPanningPlot("Acceleration with IIR", -20, 20)
qtPanningPlot2 = QtPanningPlot("Pushup Position", -1, 1)
qtPanningPlot3 = QtPanningPlot("Acceleration without IIR", -20, 20)
qtPanningPlot4 = QtPanningPlot("Sampling Rate", -100, 100)


class DataCollector():
    def __init__(self):

        # called for every new sample at channel 0 which has arrived from the Arduino
        # "data" contains the new sample

        self.lastAcc = 0
        self.velocity = 0
        self.lastVel = 0
        self.displacement = 0
        self.lastDisp = 0
        self.value = 0
        self.lastvalue = 0
        self.uptime = 0
        self.downtime = 0
        self.standardPushupCount = 0
        self.lasttime = time.time()
        self.realSamplingrate = 50

    def start(self):

        # sampling rate: 10Hz create the filters
        self.samplingRate = 10
        self.coefficient1=  butter(2, [0.1],'highpass',output='sos')
        self.coefficient2 = butter(2, [0.6], 'lowpass', output='sos')
        self.filter1 = IIR_filter(self.coefficient1)
        self.filter2 = IIR_filter(self.coefficient2)

        # Get the Ardunio board.
        self.board = Arduino(PORT)

        # Set the sampling rate in the Arduino
        self.board.samplingOn(1000 / self.samplingRate)

        self.board.analog[2].register_callback(self.callBack)

        # Enable the callback
        self.board.analog[2].enable_reporting()

    def callBack(self, data):
        # filter your channel 0 samples here:
        # data = self.filter_of_channel0.dofilter(data)
        # send the sample to the plotwindow
        self.nowtime = time.time()

        if (self.nowtime - self.lasttime) != 0:
            self.realSamplingrate = 1 / (self.nowtime - self.lasttime)
            self.lasttime = self.nowtime
        self.unfilterData = data
        self.unfilterAcceleration = self.unfilterData * 9.81 * 3.3
        data = self.filter1.filter(data)
        data = self.filter2.filter(data)

        self.acceleration = data * 9.81 * 3.3

        #Calculation of velocity and displacement by using the trapezoidal rule
        self.velocity = self.lastVel + 1 / 2 * (1 / self.samplingRate) * (self.lastAcc + self.acceleration)



        self.displacement = abs(self.lastDisp + 1 / 2 * (1 / self.samplingRate) * (self.lastVel + self.velocity))
        self.displacement = self.filter1.filter(self.displacement)
        #Do the thesholding for the displacement
        if self.displacement > 0.06:
            self.value = 1
            #calculate the tiem when uping
            self.now_time = datetime.now()
            self.new_time_minute = int(self.now_time.strftime('%M'))
            self.new_time_second = int(self.now_time.strftime('%S'))
            self.uptime = self.new_time_minute * 60 + self.new_time_second
        elif self.displacement < -0.06:
            self.value = -1
            # calculate the tiem when downing
            self.now_time = datetime.now()
            self.new_time_minute = int(self.now_time.strftime('%M'))
            self.new_time_second = int(self.now_time.strftime('%S'))
            self.downtime = self.new_time_minute * 60 + self.new_time_second
            if self.uptime != 0 and self.downtime - self.uptime < 2:
                self.standardPushupCount = self.standardPushupCount + 1
                self.uptime = 0
                self.downtime = 0
                print("The number of standard sit ups is: " + str(self.standardPushupCount))
        else:
            self.value = self.lastvalue

        # print("Velocity is"+str(self.velocity))
        # print("Displancement is"+str(self.displacement))
        # update accelaration velocity and displacement
        self.lastAcc = data
        self.lastVel = self.velocity
        self.lastDisp = self.displacement
        self.lastvalue = self.value
        qtPanningPlot1.addData(self.acceleration)
        qtPanningPlot2.addData(self.value)
        qtPanningPlot3.addData(self.unfilterAcceleration)
        qtPanningPlot4.addData(self.realSamplingrate)

    def stop(self):
        self.board.samplingOff()
        self.board.exit()


device = DataCollector()

device.start()

app.exec_()

device.stop()

print("Finished")
