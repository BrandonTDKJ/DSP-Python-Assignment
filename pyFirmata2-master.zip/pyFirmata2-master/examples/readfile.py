import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

data = pd.read_csv('results.csv')
max_val = 0.5
amplitude = np.array(data['displacement'])
amplitude_norm = amplitude/max_val
total_samples = np.size(amplitude)

sample_rate= 25
freq_step  = sample_rate/total_samples
freq_domain = np.linspace(0,(total_samples-1)*freq_step,total_samples)
freq_domain_plt = freq_domain[:int(total_samples/2)+1]
freq_mag = np.fft.fft(amplitude_norm)
freq_mag_abs = np.abs(freq_mag)/total_samples
freq_mag_abs_plt = 2*freq_mag_abs[:int(total_samples/2)+1]
plt.plot(freq_domain_plt,freq_mag_abs_plt)
plt.xlabel("Freqyency(Hz)")
plt.ylabel("Amplitude(dB)")
plt.grid()
plt.show()