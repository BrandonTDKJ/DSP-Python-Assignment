from examples.iir_filter import  IIR_filter
from examples.iir_filter import  IIR2_filter
import matplotlib.pyplot as plt
import numpy as np
from scipy.signal import butter
import numpy as np
import pandas as pd

def unitTest(cutoffFrequency, order,datas):
    sos = butter(order, cutoffFrequency * 2, output='sos')
    IIR_filter1 = IIR_filter(sos)
    output = []
    for data in datas:
        output.append(IIR_filter1.filter(data))
    return output

def fftTransform(datas):
    total_samples = np.size(datas)
    sample_rate = 50
    freq_step = sample_rate / total_samples
    freq_domain = np.linspace(0, (total_samples - 1) * freq_step, total_samples)
    freq_domain_plt = freq_domain[:int(total_samples / 2) + 1]
    freq_mag = np.fft.fft(amplitude_norm)
    freq_mag_abs = np.abs(freq_mag) / total_samples
    freq_mag_abs_plt = 2 * freq_mag_abs[:int(total_samples / 2) + 1]
    plt.plot(freq_domain_plt, freq_mag_abs_plt)
    plt.xlabel("Freqyency(Hz)")
    plt.ylabel("Amplitude(dB)")
    plt.grid()
    plt.show()

if __name__ == '__main__':
    data = pd.read_csv('results.csv')
    amplitude = np.array(data['displacement'])
    max_val = max(amplitude)
    amplitude_norm = amplitude / max_val
    fftTransform(amplitude_norm)
    amplitude_norm = unitTest(0.1, 2,amplitude_norm)
    amplitude_norm = np.array(amplitude_norm)
    fftTransform(amplitude_norm)

