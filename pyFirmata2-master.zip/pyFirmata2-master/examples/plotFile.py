import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

data = pd.read_csv('results.csv')
max_val = 0.5
amplitude = np.array(data['acceleration'])
time = np.array(data['time'])
velocity = np.array(data['velocity'])
displacement = np.array(data['displacement'])

plt.plot(time,displacement)
plt.show()