# sampling rate: 1kHz

import sys

import pyqtgraph as pg
from pyqtgraph.Qt import QtCore, QtGui

from examples.iir_filter import  IIR2_filter
from examples.iir_filter import  IIR_filter
from scipy.signal import butter

import numpy as np


class multigraphs:
    def __init__(self):
        self.samplingRate = 10
        self.acc = 0
        self.lastAcc = 0
        self.velocity = 0
        self.lastVel = 0
        self.displacement = 0
        self.lastDisp = 0
        self.coefficient = butter(2, [0.1], 'highpass', output='sos')
        self.filter1 = IIR2_filter(self.coefficient)

    def update(self,data):
        # filter your channel 0 samples here:
        # data = self.filter_of_channel0.dofilter(data)
        # send the sample to the plotwindow
        data = self.filter1.filter(data)
        acceleration = data * 9.81 * 3

        self.velocity = self.lastVel + 1 / 2 * (1 / self.samplingRate) * (self.lastAcc + acceleration)
        self.displacement = self.lastDisp + 1 / 2 * (1 / self.samplingRate) * (self.lastVel + self.velocity)

        # print("Velocity is"+str(self.velocity))
        # print("Displancement is"+str(self.displacement))
        # update accelaration velocity and displacement
        self.lastAcceleration = self.acceleration
        self.lastVel = self.velocity
        self.lastDisp = self.displacement
