# Examples

![alt tag](screenshot_realtime_scope.png)

  - Realtime oscilloscope. This script shows how to process data at a given sampling rate.
  - Printing data on the screen using an event handler
  - Digital in reads from a digital pin using an event handler
  - Flashing LED using a timer
  - PWM
  - Servo
