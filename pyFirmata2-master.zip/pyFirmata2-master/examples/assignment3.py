#!/usr/bin/python3
"""
Plots channel zero at 1kHz. Requires pyqtgraph.

Copyright (c) 2018-2021, Bernd Porr <mail@berndporr.me.uk>
see LICENSE file.

"""

import sys

import pyqtgraph as pg
from pyqtgraph.Qt import QtCore, QtGui

from examples.iir_filter import IIR2_filter
from examples.iir_filter import IIR_filter
from scipy.signal import butter

import numpy as np

from pyfirmata2 import Arduino

PORT = Arduino.AUTODETECT

# create a global QT application object
app = QtGui.QApplication(sys.argv)

# signals to all threads in endless loops that we'd like to run these
running = True


class QtPanningPlot:

    def __init__(self, title):
        self.win = pg.GraphicsLayoutWidget()
        self.win.setWindowTitle(title)
        self.plt = self.win.addPlot()

        self.plt.setYRange(-5, 5)
        self.plt.setXRange(0, 500)
        self.curve = self.plt.plot()
        self.data = []
        # any additional initalisation code goes here (filters etc)
        self.timer = QtCore.QTimer()
        self.timer.timeout.connect(self.update)
        self.timer.start(100)
        self.layout = QtGui.QGridLayout()
        self.win.setLayout(self.layout)
        self.win.show()

        self.acceleration = 0
        self.velocity = 0
        self.displacement = 0

        self.lastAcceleration = 0
        self.lastVelocity = 0
        self.lastDisplacement = 0

    def update(self):
        self.data = self.data[-500:]
        if self.data:
            self.curve.setData(np.hstack(self.data))

    def addData(self, d):
        self.data.append(d)


# Let's create two instances of plot windows
qtPanningPlot1 = QtPanningPlot("Acceleration")
qtPanningPlot2 = QtPanningPlot("Velocity")
qtPanningPlot3 = QtPanningPlot("Displacement")

# sampling rate: 1kHz
samplingRate = 10

coefficient = butter(2, [0.1], 'highpass', output='sos')

filter1 = IIR2_filter(coefficient)

class DataCollector:

    def __init__(self):
        # sampling rate: 10Hz
        self.samplingRate = 10
        self.timestamp = 0
        self.board = Arduino(PORT)

    def start(self):
        self.board.analog[0].register_callback(self.myPrintCallback)
        self.board.samplingOn(1000 / self.samplingRate)
        self.board.analog[0].enable_reporting()

    def myPrintCallback(self, data):
        #filter data here

    def stop(self):
        self.board.samplingOff()
        self.board.exit()
# called for every new sample at channel 0 which has arrived from the Arduino
# "data" contains the new sample
def callBack(data):
    # filter your channel 0 samples here:
    # data = self.filter_of_channel0.dofilter(data)
    # send the sample to the plotwindow
    data = filter1.filter(data)
    acceleration = data * 9.81 * 3
    lasAcc
    velocity
    lastVel
    displacement
    lastDisp
    qtPanningPlot1.addData(acceleration)
    qtPanningPlot2.addData(velocity)
    qtPanningPlot3.addData(displacement)


# Get the Ardunio board.
board = Arduino(PORT)

# Set the sampling rate in the Arduino
board.samplingOn(1000 / samplingRate)

# Register the callback which adds the data to the animated plot
# The function "callback" (see above) is called when data has
# arrived on channel 0.
board.analog[2].register_callback(callBack)

# Enable the callback
board.analog[2].enable_reporting()
board.analog[1].enable_reporting()

# showing all the windows
app.exec_()

# needs to be called to close the serial port
board.exit()

print("Finished")
