#!/usr/bin/python3
"""
Plots channel zero at 1kHz. Requires pyqtgraph.

Copyright (c) 2018-2021, Bernd Porr <mail@berndporr.me.uk>
see LICENSE file.

"""

import sys
from datetime import datetime, timedelta
import pyqtgraph as pg
from pyqtgraph.Qt import QtCore, QtGui

from examples.iir_filter import  IIR2_filter

from scipy.signal import butter

import numpy as np

from pyfirmata2 import Arduino
PORT = Arduino.AUTODETECT

# create a global QT application object
# noinspection PyUnresolvedReferences
app = QtGui.QApplication(sys.argv)

# signals to all threads in endless loops that we'd like to run these
running = True

class QtPanningPlot:

    def __init__(self,title, maxVal, minVal):
        self.win = pg.GraphicsLayoutWidget()
        self.win.setWindowTitle(title)
        self.plt = self.win.addPlot()
        self.maxVal = maxVal
        self.minVal = minVal

        self.plt.setYRange(self.minVal, self.maxVal)
        self.plt.setXRange(0,1000)
        self.curve = self.plt.plot()
        self.data = []
        # any additional initalisation code goes here (filters etc)
        self.timer = QtCore.QTimer()
        self.timer.timeout.connect(self.update)
        self.timer.start(100)
        self.layout = QtGui.QGridLayout()
        self.win.setLayout(self.layout)
        self.win.show()
        
    def update(self):
        self.data=self.data[-500:]
        if self.data:
            self.curve.setData(np.hstack(self.data))

    def addData(self,d):
        self.data.append(d)

# Let's create two instances of plot windows
qtPanningPlot1 = QtPanningPlot("Acceleration with IIR",-4,4)
qtPanningPlot2 = QtPanningPlot("Pushup Position",-1,1)
qtPanningPlot3 = QtPanningPlot("Acceleration without IIR",-1,1)

# sampling rate: 1kHz
samplingRate = 50

coefficient1 = butter(2, [0.1], 'highpass', output='sos')
coefficient2 = butter(2, [0.8], 'lowpass', output='sos')

filter1 = IIR2_filter(coefficient1[0])
filter2 = IIR2_filter(coefficient2[0])

# called for every new sample at channel 0 which has arrived from the Arduino
# "data" contains the new sample

lastAcc = 0
velocity = 0
lastVel = 0
displacement = 0
lastDisp = 0
value = 0
lastvalue = 0
uptime = 0
downtime = 0
standardPushupCount = 0

def callBack(data):
    # filter your channel 0 samples here:
    # data = self.filter_of_channel0.dofilter(data)
    # send the sample to the plotwindow
    unfilterData = data
    print("unfilterData :  "+str(data))
    data = filter1.filter(data)
    data = filter2.filter(data)

    acceleration = data * 9.81 * 3.3
    unfilterAcceleration = unfilterData
    global lastAcc
    global lastVel
    global lastDisp
    global velocity
    global displacement
    global value
    global lastvalue
    global uptime
    global downtime
    global standardPushupCount
    velocity = lastVel + 1 / 2 * (1/samplingRate) * (lastAcc + acceleration)
    displacement =  abs(lastDisp + 1 / 2 * (1/samplingRate) * (lastVel + velocity))
    displacement = filter1.filter(displacement)
    print("displacement is: "+str(displacement))
    if displacement>0.06:
        value = 1
        now_time = datetime.now()
        new_time_minute = int(now_time.strftime('%M'))
        new_time_second = int(now_time.strftime('%S'))
        uptime = new_time_minute*60+new_time_second
    elif displacement<-0.06:
        value = -1
        now_time = datetime.now()
        new_time_minute = int(now_time.strftime('%M'))
        new_time_second = int(now_time.strftime('%S'))
        downtime = new_time_minute * 60 + new_time_second
        if uptime!=0 and downtime-uptime<2:
            standardPushupCount = standardPushupCount+1
            uptime = 0
            downtime = 0
    else:
        value = lastvalue

    # print("Velocity is"+str(self.velocity))
    # print("Displancement is"+str(self.displacement))
    # update accelaration velocity and displacement
    lastAcc = data
    lastVel = velocity
    lastDisp = displacement
    lastvalue = value
    qtPanningPlot1.addData(acceleration)
    qtPanningPlot2.addData(value)
    qtPanningPlot3.addData(unfilterAcceleration)
    print("unfilter :    "+str(unfilterAcceleration))

    print("The number of standard pushup is: "+str(standardPushupCount))

# Get the Ardunio board.
board = Arduino(PORT)

# Set the sampling rate in the Arduino
board.samplingOn(1000 / samplingRate)

# Register the callback which adds the data to the animated plot
# The function "callback" (see above) is called when data has
# arrived on channel 0.
board.analog[2].register_callback(callBack)

# Enable the callback
board.analog[2].enable_reporting()
board.analog[1].enable_reporting()

# showing all the windows
app.exec_()

# needs to be called to close the serial port
board.exit()

print("Finished")
